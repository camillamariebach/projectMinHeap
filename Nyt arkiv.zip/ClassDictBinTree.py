"""Class dictBinTree"""
from binNode import BinNode

class DictBinTree():
    """A class to represent a binary tree"""

    def __init__(self):
        self.root = BinNode()

    """Methods for class dictBinTree"""

    def search(T, k):
        found = False
        if k == T.root:
            found = True
        if k < T.root:
            search(T.root.left, k)
        else: search(T.root.right, k)
        return found 

    def iterativeTreeSearch (T, k):
        while T[0] != None and k != T[0]:
            if k < T[0]:
                T = T[1]
            else: T = T[2]
        return T

    def insert(T, k):
        y = None
        x = T.root
        print(x.key)
        newNode = BinNode()
        newNode.key = k
        print("x.key :")
        print(x.key)
    
        print(x.key is not None)
        while x.key is not None:
            count = 1
            y = x
            print(x.key is not None)

            print('newnode.key:')
            print(newNode.key)
            print(newNode.key < x.key)
            if newNode.key < x.key:
                T.root.left = x
                print('x:')
                print(x)
                print('T.root.left')
                print(T.root.left)
            else: 
                T.root.right = x
                print('x:')
                print(x)
                print('T.root.right')
                print(T.root.right)
            
            print('iteration nr:')
            print(count)
            count +=1 
                
        if y == None:
            T.root = newNode
            print('T.root:')
            print(T.root)
            print(newNode)
            print('T.root.key:')
            print(T.root.key)
        elif newNode.key < y.key:
            y.left = newNode
        else: y.right = newNode
        
    def orderedTraversal(T):
        inorderTreewalk(T.root)

    def inorderTreewalk(x):
        orderedlist = []
        if x != None: 
            inorderTreewalk(x.left)
            orderedlist.append(x)
            inorderTreewalk(x.right)