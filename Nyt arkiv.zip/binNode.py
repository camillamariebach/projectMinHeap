"""Class BinNode"""

class BinNode():
    """A class to represent a binary node in a binary tree"""

    def __init__(self):
        self.key = None
        self.left = None
        self.right = None
        